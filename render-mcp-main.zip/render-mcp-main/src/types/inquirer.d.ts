declare module 'inquirer';
